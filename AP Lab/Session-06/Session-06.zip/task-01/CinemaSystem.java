import java.util.ArrayList;
import java.util.Date;

public class CinemaSystem 
{
    ArrayList<Salon> salons;
    ArrayList<Costumer> costumers;

    public void displayShow(String name, Date date)
    {

    }

    public void saveReserve(Costumer costumer, ArrayList<Chair> chairs)
    {

    }

    public void deleteReserve(Costumer costumer,Show show)
    {

    }

    public void addCostumer()
    {
        
    }
}
