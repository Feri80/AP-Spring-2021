import java.util.ArrayList;


public class Salon 
{
    ArrayList<Show> shows;

    public void displayShows()
    {

    }

    public void addShow()
    {
        
    }
}
