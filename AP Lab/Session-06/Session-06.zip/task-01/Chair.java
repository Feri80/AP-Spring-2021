public class Chair 
{
    int number;
    Chair leftChair;
    Chair rightChair;

    public void getNumber()
    {

    }

    public void showAdjacentChairs()
    {

    }
    
}
