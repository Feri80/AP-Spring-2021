import java.util.ArrayList;

public class Row 
{
    ArrayList<Chair> chairs;

    public void findChair(int number)
    {

    }

    public void showAllChairs()
    {
        
    }
}
