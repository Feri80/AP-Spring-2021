import java.util.ArrayList;
import java.util.Date;

public class Show 
{
    String name;
    Date date;
    ArrayList<Row> rows;
    ArrayList<Costumer> costumers;
    int capacity;

    public void showDetails()
    {

    }

    public void addCostumer()
    {
        
    }

    public void deleteCostumer()
    {
        
    }
}
