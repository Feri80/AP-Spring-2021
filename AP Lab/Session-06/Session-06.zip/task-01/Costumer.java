import java.lang.reflect.Array;
import java.util.ArrayList;

public class Costumer 
{
    String name;
    ArrayList<Reserve> rerserves;

    public void showReserves()
    {

    }

    public void addReserve()
    {

    }

    public void deleteReserve()
    {
        
    }
}
