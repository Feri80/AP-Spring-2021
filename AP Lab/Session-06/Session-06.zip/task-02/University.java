import java.util.ArrayList;

public class University 
{
    ArrayList<Patient> patients;

    public void addPatient()
    {

    }

    
}
