import java.util.ArrayList;

public class Pharmacy 
{
    ArrayList<Patient> patients;

    public void addPatient()
    {

    }

    public void showPrescription()
    {
        
    }
}
