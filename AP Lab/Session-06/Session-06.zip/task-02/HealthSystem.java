import java.util.ArrayList;

public class HealthSystem
{
    ArrayList<Patient> patients;
    ArrayList<Doctor> doctors;
    ArrayList<University> universities;
    ArrayList<Pharmacy> pharmacies;

    public void addPatient()
    {

    }

    public void addDoctor()
    {

    }

    public void addUniversity()
    {

    }

    public void addPharmacy()
    {

    }

    
}