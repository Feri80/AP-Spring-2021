import java.util.ArrayList;

public class Doctor 
{
    ArrayList<Access> accesses;
    

    public void addNewAccess()
    {

    }

    public void addNewTherapist()
    {

    }

    public void prescribeDrug()
    {

    }

    public void makeHistory()
    {
        
    }
}
