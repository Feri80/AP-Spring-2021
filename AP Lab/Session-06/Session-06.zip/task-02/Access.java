import java.util.ArrayList;

public class Access 
{
    Patient patient;
    ArrayList<History> accessableHistories;
    
    public void showAccess()
    {
        
    }
}
