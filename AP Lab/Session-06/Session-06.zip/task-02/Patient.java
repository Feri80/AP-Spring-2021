import java.util.ArrayList;
import java.util.Date;

public class Patient 
{
    String name;
    Date birthday;
    String sex;
    String career;
    String degreeOfEducation;
    String basicInsurance;
    String supplementaryInsurance;
    String location;
    ArrayList<History> histories;
    ArrayList<Doctor> trustworthyDoctors;

    public void showHistories()
    {

    }

    public void giveLicense()
    {

    }

    public void chooseFirstTrustworthyDoctor()
    {

    }

    
}
