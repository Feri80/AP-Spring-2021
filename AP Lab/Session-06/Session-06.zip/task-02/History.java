import java.util.Date;

public class History 
{
    String generalTypeOfDisease;
    String patientSituation;
    String physicianDiagnosis;
    String securityLevel;
    String drug;
    Date date;
    Doctor Therapist;
    
    public void showHistory()
    {

    }

}
